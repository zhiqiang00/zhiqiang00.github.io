# resume-theme
this is a theme about resume based on hexo .

If you want to know how use the thme,please check on  [https://github.com/aeneag/resume-hexo](https://github.com/aeneag/resume-hexo)



Resume page [https://dxinxia.top](https://dxinxia.top)

Personal blog [https://aeneag.xyz](https://aeneag.xyz)



Wechat Official Accounts

<img style="height: 240px;width: 240px; " src="https://b3logfile.com/file/2021/11/qrcode_for_gh_6991d24e23e2_344-91ebc4df.jpg" alt="个人公众号">

Wechat

<img style="height: 240px;width: 240px; " src="https://b3logfile.com/file/2021/11/WechatIMG91-dc5e5be8.jpeg" alt="个人微信">

